package com.example.dungnvph26746_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Bai1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);
        ImageView imageView= findViewById(R.id.imageView);
        findViewById(R.id.btn_zoom).setOnClickListener(view -> {
            Animation animation= AnimationUtils.loadAnimation(this,R.anim.zoom);
            imageView.startAnimation(animation);
        });

        findViewById(R.id.btn_rotation).setOnClickListener(view -> {
            int dest= 360;
            if (imageView .getRotation()==360) {
                System.out.print(imageView.getAlpha());
                dest=0;
            }
            ObjectAnimator animator= ObjectAnimator.ofFloat(imageView,"rotation",dest);
            animator.setDuration(2000);
            animator.start();
        });
        findViewById(R.id.btn_moving).setOnClickListener(view -> {
            Animation animation= AnimationUtils.loadAnimation(this,R.anim.moving);
            imageView.startAnimation(animation);
        });
    }

}