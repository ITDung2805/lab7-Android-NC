package com.example.dungnvph26746_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Bai3Activity extends AppCompatActivity {

    ImageView imageView,imgsecond, imghours, imgminute;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);
        imageView=findViewById(R.id.ImgClock);
        imageView.setImageResource(R.drawable.bg);
        imgsecond=findViewById(R.id.secondImage);
        imgsecond.setImageResource(R.drawable.second);
        imgminute=findViewById(R.id.MinuteImage);
        imgminute.setImageResource(R.drawable.minute);
        imghours=findViewById(R.id.HourImage);
        imghours.setImageResource(R.drawable.hour);

        findViewById(R.id.btn_run).setOnClickListener(view -> {

            Runoclock();
        });
    }

    public void Runoclock() {
        Animation animationHour= AnimationUtils.loadAnimation(this,R.anim.hour);
        Animation animationminte= AnimationUtils.loadAnimation(this,R.anim.minte);
        Animation animationsecond= AnimationUtils.loadAnimation(this,R.anim.second);
        imghours.startAnimation(animationHour);
        imgminute.startAnimation(animationminte);
        imgsecond.startAnimation(animationsecond);
    }
}