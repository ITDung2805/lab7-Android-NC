package com.example.dungnvph26746_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Bai2Activity extends AppCompatActivity {

    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);
        imageView=findViewById(R.id.imageView2);

        findViewById(R.id.btn_all).setOnClickListener(view -> {
            All();
        });
        findViewById(R.id.btn_doraemon).setOnClickListener(view -> {
            doraemon();
        });
        findViewById(R.id.btn_nobita).setOnClickListener(view -> {
            nobita();
        });
        findViewById(R.id.btn_xuka).setOnClickListener(view -> {
            xuka();
        });
        findViewById(R.id.btn_chaien).setOnClickListener(view -> {
            chaien();
        });
    }

    public void All() {
        imageView.setImageResource(R.drawable.all);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.slidelshow);
        imageView.startAnimation(animation);
    }

    public void doraemon() {
        imageView.setImageResource(R.drawable.doraemon);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.slidelshow);
        imageView.startAnimation(animation);
    }
    public void nobita() {
        imageView.setImageResource(R.drawable.nobita);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.slidelshow);
        imageView.startAnimation(animation);
    }

    public void xuka() {
        imageView.setImageResource(R.drawable.xuka);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.slidelshow);
        imageView.startAnimation(animation);
    }

    public void chaien() {
        imageView.setImageResource(R.drawable.chaien);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.slidelshow);
        imageView.startAnimation(animation);
    }

}